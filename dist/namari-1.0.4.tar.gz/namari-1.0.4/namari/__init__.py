""" namari """
from .version import version as __version__
from .namari import Namari
__all__ = ["namari"]