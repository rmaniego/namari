""" namari """
__version__ = "1.1.9"
from .namari import Namari
__all__ = ["namari"]